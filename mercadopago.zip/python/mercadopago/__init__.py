"""
Module: mercadopago/__init__.py
"""
from mercadopago.sdk import SDK


__all__ = (
    'SDK',
)
